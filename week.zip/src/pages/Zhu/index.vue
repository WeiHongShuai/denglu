<template>
    <div class="Zhu">
        <p>用户名:<input type="text" v-model="uName"></p>
      <p>密码:<input type="text" v-model="uPwd"></p>
      <p> <button @click="zhu">注册</button> </p>

    </div>
  
</template>

<script>
export default {
    data(){
        return{
            uName:"",
            uPwd:""
        }
    },
    methods:{
        zhu(){
            let uName = this.uName
            let uPwd = this.uPwd
            console.log(uPwd)
            let url="http://localhost:8888/vue/week/api/test.php?uName="+uName+"&uPwd="+uPwd;
            console.log(url)
            this.$axios.get(url).then((res)=>{
                

                if(res.data.msg=='ok'){
                     localStorage["uToken"] = res.data.token
                    console.log(res.data.token)
                    alert('注册成功')
                    // this.$router.push('/')
                    
                }
            })
        }
    }
    

}
</script>

<style>
.Zhu{
    width: 100%;
    height: 100%;
}

</style>