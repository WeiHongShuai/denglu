import Vue from 'vue'
import Router from 'vue-router'
import Login from '../pages/Login/index.vue'
import Zhu from '../pages/Zhu/index.vue'

Vue.use(Router);
const createRouter = () =>new Router({
    routes:[
        {
            name:'',
            path:'/',
            component:Login
        },
        {
            name:'zhu',
            path:'/zhu',
            component:Zhu
        }
    ]
})
const router = createRouter()
export default router