import Vue from 'vue'
import Router from 'vue-router'
import Login from '../pages/Login/index.vue'
import Zhu from '../pages/Zhu/index.vue'
import Main from '../pages/main/index.vue'

Vue.use(Router);
const createRouter = () =>new Router({
    routes:[
        {
            name:'',
            path:'/',
            component:Login
        },
        {
            name:'zhu',
            path:'/zhu',
            component:Zhu
        },
        {
            name:'main',
            path:'/main',
            component:Main
        }
    ]
})
const router = createRouter()
export default router