<?php 
    header('Access-Control-Allow-Origin:*');
    include("conn.php");
    $uName=$_GET["uName"];
    $uPwd=$_GET["uPwd"];
    $token=$_GET["token"];
    $sql="select * from week where uName='{$uName}'";
    $result=mysql_query($sql);
    $rs=mysql_Fetch_assoc($result);
    $num=mysql_num_rows($result);
    if($num>0){
        if($uPwd==$rs["uPwd"]){
            $arr=array("msg"=>"loginOk");
            echo json_encode($arr);
        
        }else{
            $arr=array("msg"=>"no");
            echo json_encode($arr);
        }
    }else{
        $arr=array("msg"=>"no");
        echo json_encode($arr);
    }
 ?>